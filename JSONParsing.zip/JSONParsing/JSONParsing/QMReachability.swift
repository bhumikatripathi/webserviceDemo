//
//  QMReachability.swift
//  QuaterlyMagazine
//
//  Created by indianic on 12/07/17.
//  Copyright © 2017 indianic. All rights reserved.
//

import Foundation
import UIKit
import Reachability


func isNetworkAvailable() -> Bool {
    
    var isAvailable:Bool?
    
    let hostStatus = Reachability.forInternetConnection().currentReachabilityStatus()
    
    switch hostStatus {
    case .NotReachable:
        isAvailable = false
        
    case .ReachableViaWiFi:
        isAvailable = true
        
    case .ReachableViaWWAN:
        isAvailable = true
        
    }
    
    return isAvailable!
    
}
