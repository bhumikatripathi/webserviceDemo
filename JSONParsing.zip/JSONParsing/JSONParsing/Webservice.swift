//
//  Webservice.swift
//  JSONParsing
//
//  Created by Urvish Patel on 10/8/17.
//  Copyright © 2017 Urvish Patel. All rights reserved.
//

import UIKit
import SVProgressHUD
import SwiftyJSON
import Reachability


class Webservice: NSObject {
    
    
    func showIndicator() {
        SVProgressHUD.show()
        UIApplication.shared.beginIgnoringInteractionEvents()
    }
    
    func hideIndicator() {
        SVProgressHUD.dismiss()
        UIApplication.shared.endIgnoringInteractionEvents()
    }
    
    //Post
    class func wsCallPostService(_ controller : UIViewController , aStrURL : String , param : [String : Any]? , useToken : Bool , showIndicator : Bool, completionHandler:@escaping (JSON? , _ error:Error?, _ networkError: String?) -> Void) {
        
        
        if isNetworkAvailable()
        {
            if showIndicator {
                
                DispatchQueue.main.async {
                  Webservice().showIndicator()
                }
            }
            //create the session object
            let session = URLSession.shared
            
            //now create the URLRequest object using the url object
            let strURL = aStrURL
            let urlwithPercentEscapes = strURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
            
            var request = URLRequest(url: URL(string: urlwithPercentEscapes!)!)
            
            if param != nil {
                
                request.httpMethod = "POST" //set http method as POST
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")
                request.addValue("application/json", forHTTPHeaderField: "Accept")
                
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: param!, options: .prettyPrinted)
                    request.httpBody = jsonData
                }
                    
                catch let error as NSError{
                    print(error.localizedDescription)
                }
            }
            
            
            //create dataTask using the session object to send data to the server
            let task = session.dataTask(with: request as URLRequest, completionHandler: { responseData, response, error in
                
                print("Response:\(String(describing: response))")
                print("data:\(String(describing: responseData))")
                print("error:\(String(describing: error))")
                
                
                if showIndicator {
                    DispatchQueue.main.async {
                        Webservice().hideIndicator()
                     
                    }
                }
                Webservice().hideIndicator()
               
                
                if (error != nil) {
                    
                    /* DispatchQueue.main.async {
                     SVProgressHUD.dismiss()
                     }
                     DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                     
                     
                     UIAlertController.showAlertWithOkButton(controller, aStrMessage: error!.localizedDescription, completion: { (index, response) in
                     
                     })
                     
                     }*/
                    completionHandler(nil, error, nil)
                    
                    print("Request failed with error: \(error!.localizedDescription)")
                    
                }
                else{
                    
                    let httpResponse = response as? HTTPURLResponse
                    
                    if httpResponse?.statusCode == 200
                    {
                        
                        // if let data = data {
                        
                        let json = JSON(data: responseData!)
                        
                        print("Response After Converting : \(json)")
                        completionHandler(json, nil, nil)
                        
                        //  }
                    }
                    else
                    {
                        _ = JSON(data: responseData!)
                    }
                    
                }
                
                
            })
            task.resume()
        }
        else
        {
            completionHandler(nil, nil, "No Network Available")
            
        }
    }
    
    
    //Get
    
    class func wsCallGetService(_ controller : UIViewController , aStrURL : String , param : [String : Any]? , useToken : Bool , showIndicator : Bool, completionHandler:@escaping (JSON? , _ error:Error?, _ networkError: String?) -> Void) {
        
        if isNetworkAvailable()
        {
            
            if showIndicator {
                
                DispatchQueue.main.async {
                   Webservice().showIndicator()
                   
                }
                
            }
            
            
            let url = URL(string: aStrURL)
            URLSession.shared.dataTask(with: url!, completionHandler: {
                (data, response, error) in
                
                if showIndicator {
                    DispatchQueue.main.async {
                       Webservice().hideIndicator()
                       
                    }
                }
               Webservice().hideIndicator()
              
                
                if(error != nil){
                    
                    completionHandler(nil, error, nil)
                    
                }else{
                    
                    //let json = try JSONSerialization.jsonObject(with: data!, options:.allowFragments) as! [String : AnyObject]
                    let json = JSON(data: data!)
                    print("Get Json : \(json)")
                    completionHandler(json, nil, nil)
                    
                }
            }).resume()
            
        }
            
        else
        {
            
            completionHandler(nil,nil,"No Network available.")
            
        }
        
    }
    
    
   
    
  /*
    //Alamofire
    
    //Post
    class func wsCallPost(_ controller : UIViewController , aStrURL : String , param : [String : Any]? , useToken : Bool , showIndicator : Bool, completionHandler:@escaping (JSON? , _ error:Error?, _ networkError: String?) -> Void) {
        
        if isNetworkAvailable()
        {
            
            if showIndicator {
                
                DispatchQueue.main.async {
                    SVProgressHUD.show()
                    controller.view.isUserInteractionEnabled = false
                }
                
            }
            
            
            Alamofire.request(aStrURL, method: .post, parameters: param, encoding: JSONEncoding.default, headers: nil).responseJSON { (response:DataResponse<Any>) in
                
                if showIndicator {
                    DispatchQueue.main.async {
                        SVProgressHUD.dismiss()
                        controller.view.isUserInteractionEnabled = true
                    }
                }
                SVProgressHUD.dismiss()
                controller.view.isUserInteractionEnabled = true
                
                switch(response.result) {
                case .success(_):
                    if response.result.value != nil{
                        print(response.result.value!)
                    }
                    let json = JSON(response.result.value!)
                    completionHandler(json, nil, nil)
                    
                    break
                    
                case .failure(_):
                    print(response.result.error!)
                    completionHandler(nil,response.result.error!, nil)
                    
                    break
                }
            }
        }
            
        else{
            
            //Network Error
            completionHandler(nil, nil, QMMessageConstant.kNoNetwork)
        }
        
    }
    
    //Get
    
    class func wsCallGet(_ controller : UIViewController , aStrURL : String , param : [String : Any]? , useToken : Bool , showIndicator : Bool, completionHandler:@escaping (JSON? , _ error:Error?, _ networkError: String?) -> Void) {
        
        
        if isNetworkAvailable()
        {
            
            if showIndicator {
                
                DispatchQueue.main.async {
                    //                    SVProgressHUD.setFadeInAnimationDuration(0.0)
                    //                    SVProgressHUD.setFadeOutAnimationDuration(0.0)
                    //                    SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.clear)
                    SVProgressHUD.show(withStatus: QMMessageConstant.kPleaseWait)
                    controller.view.isUserInteractionEnabled = false
                }
                
            }
            
            Alamofire.request(aStrURL, method: .get, parameters: param, encoding: URLEncoding.default, headers: nil).responseJSON { (response:DataResponse<Any>) in
                
                if showIndicator {
                    DispatchQueue.main.async {
                        SVProgressHUD.dismiss()
                        controller.view.isUserInteractionEnabled = true
                    }
                }
                SVProgressHUD.dismiss()
                controller.view.isUserInteractionEnabled = true
                
                switch(response.result) {
                case .success(_):
                    if response.result.value != nil{
                        print(response.result.value!)
                    }
                    
                    let json = JSON(response.result.value!)
                    completionHandler(json, nil, nil)
                    
                    break
                    
                case .failure(_):
                    print(response.result.error!)
                    completionHandler(nil,response.result.error!, nil)
                    break
                    
                }
            }
            
            
        }
        else{
            
            //Network error
            completionHandler(nil, nil, QMMessageConstant.kNoNetwork)
        }
        
        
    }*/
    
}
